import React from "react";

const ResourceCard = () => {
  return (
    <div>ResourceCard component</div>
  );
};

export default ResourceCard;
