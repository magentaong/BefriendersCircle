import React from "react";

const CreateTopicModal = () => {
  return (
    <div>CreateTopicModal component</div>
  );
};

export default CreateTopicModal;
