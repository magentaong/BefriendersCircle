import React from "react";

const CreatePostModal = () => {
  return (
    <div>CreatePostModal component</div>
  );
};

export default CreatePostModal;
