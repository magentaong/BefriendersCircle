import React from "react";

const ReplyModal = () => {
  return (
    <div>ReplyModal component</div>
  );
};

export default ReplyModal;
