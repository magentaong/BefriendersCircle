//Start of creating a Responsive Header Bar
import { Link } from "react-router-dom";
import { ArrowLeft, ArrowRight } from "lucide-react";
import SearchBar from "./SearchBar";

interface HeaderProps {
  title: string;
  leftLink?: string;
  rightLink?: string;
  onSearch?: (query: string) => void;
  onVoiceInput?: () => void;
  searchPlaceholder?: string;
  showSearch?: boolean;
}

export default function Header({ 
  title, 
  leftLink, 
  rightLink, 
  onSearch,
  onVoiceInput,
  searchPlaceholder = "Search...",
  showSearch = false
}: HeaderProps) {
  return (
    <header className="header-bar">
      {/* Left Navigation */}
      <div className="flex items-center gap-2 md:gap-4">
        {leftLink ? (
          <Link to={leftLink} className="p-2 rounded-full bg-latte hover:brightness-90 transition-all">
            <ArrowLeft className="w-5 h-5 text-charcoal" />
          </Link>
        ) : <div className="w-9" />}
        
        <h1 className="text-base md:text-lg font-bold text-charcoal">{title}</h1>
      </div>

      {/* Center Search Bar - Mobile Responsive */}
      {showSearch && onSearch && (
        <div className="flex-1 max-w-xs md:max-w-md mx-2 md:mx-4">
          <SearchBar 
            onSearch={onSearch}
            onVoiceInput={onVoiceInput}
            placeholder={searchPlaceholder}
            className="w-full"
          />
        </div>
      )}

      {/* Right Navigation */}
      <div className="flex items-center gap-2 md:gap-4">
        {rightLink ? (
          <Link to={rightLink} className="p-2 rounded-full bg-latte hover:brightness-90 transition-all">
            <ArrowRight className="w-5 h-5 text-charcoal" />
          </Link>
        ) : <div className="w-9" />}
      </div>
    </header>
  );
}

//end of creating a Responsive Header Bar