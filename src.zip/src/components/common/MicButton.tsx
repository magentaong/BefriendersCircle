import React from "react";

const MicButton = () => {
  return (
    <div>MicButton component</div>
  );
};

export default MicButton;
