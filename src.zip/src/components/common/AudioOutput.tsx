import React from "react";

const AudioOutput = () => {
  return (
    <div>AudioOutput component</div>
  );
};

export default AudioOutput;
