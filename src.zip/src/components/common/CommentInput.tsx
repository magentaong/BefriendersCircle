import React from "react";

const CommentInput = () => {
  return (
    <div>CommentInput component</div>
  );
};

export default CommentInput;
