import React from "react";

const NavBar = () => {
  return (
    <div>NavBar component</div>
  );
};

export default NavBar;
