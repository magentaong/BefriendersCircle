import { Swiper, SwiperSlide } from "swiper/react";
import { Navigation, Pagination, Autoplay } from "swiper/modules";
import "swiper/css";
import "swiper/css/navigation";
import "swiper/css/pagination";
import ModularCard from "./ModularCard";

interface Resource {
  id: string;
  title: string;
  description: string;
  tags: string[];
  image?: string;
  url?: string;
}

interface ModularCardSliderProps {
  resources: Resource[];
}

export default function ModularCardSlider({ resources }: ModularCardSliderProps) {
  return (
    <div className="w-full">
      <Swiper
        modules={[Navigation, Pagination, Autoplay]}
        spaceBetween={16}
        slidesPerView={1}
        navigation={{
          nextEl: '.swiper-button-next',
          prevEl: '.swiper-button-prev',
        }}
        pagination={{
          clickable: true,
          dynamicBullets: true,
        }}
        autoplay={{
          delay: 5000,
          disableOnInteraction: false,
        }}
        breakpoints={{
          480: {
            slidesPerView: 1,
            spaceBetween: 20,
          },
          768: {
            slidesPerView: 2,
            spaceBetween: 24,
          },
          1024: {
            slidesPerView: 3,
            spaceBetween: 30,
          },
        }}
        className="w-full"
      >
        {resources.map((resource) => (
          <SwiperSlide key={resource.id}>
            <ModularCard {...resource} />
          </SwiperSlide>
        ))}
        
        {/* Custom Navigation Buttons */}
        <div className="swiper-button-prev !text-charcoal !bg-white !w-10 !h-10 !rounded-full !shadow-md !border !border-latte"></div>
        <div className="swiper-button-next !text-charcoal !bg-white !w-10 !h-10 !rounded-full !shadow-md !border !border-latte"></div>
      </Swiper>
    </div>
  );
}
