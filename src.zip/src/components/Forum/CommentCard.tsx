import React from "react";

const CommentCard = () => {
  return (
    <div>CommentCard component</div>
  );
};

export default CommentCard;
