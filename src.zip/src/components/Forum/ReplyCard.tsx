import React from "react";

const ReplyCard = () => {
  return (
    <div>ReplyCard component</div>
  );
};

export default ReplyCard;
