import React from "react";

const TrainingCategoriesCard = () => {
  return (
    <div>TrainingCategoriesCard component</div>
  );
};

export default TrainingCategoriesCard;
