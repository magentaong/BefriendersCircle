import React from "react";

const CompletedTrainingModal = () => {
  return (
    <div>CompletedTrainingModal component</div>
  );
};

export default CompletedTrainingModal;
