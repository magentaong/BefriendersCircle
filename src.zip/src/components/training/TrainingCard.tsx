import React from "react";

const TrainingCard = () => {
  return (
    <div>TrainingCard component</div>
  );
};

export default TrainingCard;
